const Discord = require('discord.js');
const moment = require('moment');
const chalk = require('chalk');
const { prefix } = require('../ayarlar.json')

module.exports = client => {
  var degisenOynuyor = [
    
    "l.yardım 🔥",
    "l.davet 🔓",
    "l.istatistik 🎈",
    "l.koruma 📜",
    "Sponsor Aranıyor. 🔨"
    
  ]
  
  setInterval(function() {
    var degisenOynuyor1 = degisenOynuyor[Math.floor(Math.random() * (degisenOynuyor.length))]
    client.user.setActivity(`${degisenOynuyor1}`);

}, 1 * 2000);
  
  client.user.setStatus("online"); //dnd, idle, online, offline
  
}