const Discord = require("discord.js");

exports.run = (client, message) => {

let motion = new Discord.MessageEmbed()
  
    .setThumbnail(message.author.displayAvatarURL())
    .setAuthor(client.user.username, client.user.avatarURL)
    .addField(
      "Veriler", 
      `> <a:cangif:812002551725162576> Toplam sunucu: **${
        client.guilds.cache.size
      }** \n> <a:dogru:812001853788258346> Toplam kullanıcı: **${client.guilds.cache
        .reduce((a, b) => a + b.memberCount, 0)
        .toLocaleString()}** \n> <a:tac:811229511764934686> Toplam kanal: **${
        client.channels.cache.size
      }**`
    ) 
    .addField(
      "Bot Geliştiricisi",
      `> <a:dogru:812001853788258346> Bot geliştiricisi ➡ <@801068869506433034> | **Lale**`
    ) 
    .addField(
      "Sürümler",
      `> <a:tac:811229511764934686> Discord.js sürümü: **v${Discord.version}** \n> <a:tac:811229511764934686> Node.js sürümü: **${process.version}**`
    ) 
    .addField(
      "Gecikmeler",
      `> <a:tac:811229511764934686> Bot pingi: **${
        client.ws.ping
      }** \n> <a:cangif:812002551725162576> Mesaj gecikmesi: **${new Date().getTime() -
        message.createdTimestamp}**`
    )
    
    .setTimestamp()
    .setColor("BLUE");
  message.channel.send(motion);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  permLevel: 0,
  aliases: ["istatistik", "i"]
};

exports.help = {
  name: "istatistik",
  description: "Türkiyenin Saatini Gösterir ",
  usage: "i"
};