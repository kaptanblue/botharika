const Fadeaway = require('discord.js');
const db = require('quick.db');
exports.run = async (client, message, args) => {
let banlog = db.fetch(`banlog_${message.guild.id}`)
if(!banlog) message.channel.send('Ban log sistemi ayarlanmamış.')
var cezalı = message.mentions.users.first() || message.guild.members.cache.get(args[0]);
if(!cezalı) return message.reply("Lütfen Sunucudan Atacağım Kişiyi Belirtiniz! \n veya Kişi Sunucuda Yok!");
if(!message.guild.member(cezalı).kickable) return message.reply("Bu Kişi Kickleyemem!");
var sebep =  args.slice(1).join(' ');
message.guild.member(cezalı).kick(sebep);
var sebep2 = sebep ? sebep : "Neden Belirtilmemiş";
var Ronney = new Fadeaway.MessageEmbed().setColor("#000000").setAuthor(message.author.username)
.addField("Kicklenen Kişi ve Sebebi", `Kicklenen Kişi: **${cezalı}**\nKicklenme Nedeni: **${sebep2}**`)
const Virus = new Fadeaway.MessageEmbed().setColor("#ff0000").setAuthor('BİR KİŞİ KİCKLENDİ!').setDescription(`Kicklenen kişi: ${cezalı} \n \n Kickleyen yetkili: ${message.author} \n \n Kickleme sebebi: ${sebep2}`)
message.channel.send(Virus)
message.channel.send(Ronney);
};
exports.conf = {aliases: [], permLevel: 2}; exports.help = {name: 'kick', description: '', usage: ''};