const Discord = require('discord.js');
const talkedRecently = new Set();
let botid = ('812000744806809620')

exports.run = (client, message, args) => {
                         if (talkedRecently.has(message.author.id)) {
           return message.reply("");
    } else {

        talkedRecently.add(message.author.id);
        setTimeout(() => {
          // Removes the user from the set after a minute
          talkedRecently.delete(message.author.id);
        }, 2000);// Şuan 2 Saniyedir Değiştirebilirsiniz.
    }
    const embed = new Discord.MessageEmbed()
  .setColor('#3498db')
.addField('**Koruma Komutları**',`
**\n l.koruma-ayarlar : Aayarlarınızı gösterir.**
**\n l.caps-engel aç : Büyük harf koruma sistemini açarsınız.**
**\n l.caps-engel kapat : Büyük harf koruma sistemini kapatırsınız.**
**\n l.mod-log #kanal : Mod log kanalını belirlersiniz.**
**\n l.rol-koruma aç : Rol-koruma açarsınız.**
**\n l.rol-koruma kapat : Rol-koruma kapatırsınız.**
**\n l.kanal-koruma aç : Kanal korumasını açarsınız.**
**\n l.kanal-koruma kapat : Kanal koruma kapatırsınız.**
**\n l.reklam-engel aç : Reklam engel korumasını açarsınız.**
**\n l.reklam-engel kapat : Reklam engel korumasını kapatırsınız.**
**\n l.küfür-engel aç : Küfür engel açarsınız.**
**\n l.küfür-engel kapat : Küfür engel kapatırsınız.**
\n ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
**\n l.ban : Etiketlediğiniz Kişiyi Banlar.**
**\n l.kick : Etiketlediğiniz Kişiyi Kickler.**
**\n l.mod-log : Ban Kick Logunu Ayarlar.**
\n ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
.setImage("")
    .setFooter(`${message.author.tag} Tarafından İstendi.`, message.author.avatarURL())
.addField("**➥ Linkler**", "[:no_entry: Davet Linkim](https://discord.com/api/oauth2/authorize?client_id=812000744806809620&permissions=8&scope=bot)\n\n[:white_check_mark: Destek Sunucum](https://discord.gg/zE4gur3EAw)\n\n[:mega: Websitem](www.lalebot.cf)")
    message.channel.send(embed);

};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: 'koruma',
  description: 'Premium Rolü Hakkındaki Bilgileri Gösterir.',
  usage: 'koruma'
};