const Discord = require('discord.js');
const talkedRecently = new Set();
let botid = ('812000744806809620')

exports.run = (client, message, args) => {
                         if (talkedRecently.has(message.author.id)) {
           return message.reply("");
    } else {

        talkedRecently.add(message.author.id);
        setTimeout(() => {
          // Removes the user from the set after a minute
          talkedRecently.delete(message.author.id);
        }, 2000);// Şuan 2 Saniyedir Değiştirebilirsiniz.
    }
    const embed = new Discord.MessageEmbed()
  .setColor('YELLOW')
.addField('**Moderasyon Komutları**',`
\n ━━━━━━━━━━━━━━━━━━━━━━━━━━━━
**\n l.afk : Afk Olursun.**
**\n l.ban : Etiketlediğiniz Kişiyi Banlar.**
**\n l.unban : Banladğınız Kişinin Banını Açar.**
**\n l.ban-sorgula : Ban Hakkında Bilgi Verir.**
**\n l.jail : Etiketlediğiniz Kişiyi Hapse Atar.**
**\n l.unjail : Etiketlediğiniz Kişinin Hapsini Kaldırır.**
**\n l.kilit : Etiketlediğiniz Kanalı Kilitler.**
**\n l.kilitaç : Etiketlediğiniz Kanalı Kilidini Açar.**
**\n l.mute : Etiketlediğini Kişiyi Muteler.**
**\n l.unmute : Etiketlediğiniz Kişinin Mutesini Açar.**
**\n l.say : Sunucunun Bilgilerini Sayar.**
**\n l.sil : Yazdığınız Sayı Kadar Mesajları Siler.**
**\n l.snipe : Son Sildiğiniz Mesajı Yakalar.**
**\n l.vmute : Sesteki Etiketlediğiniz Birini Mutelersiniz.**
**\n l.unvmute : Sesteki Etiketlediğiniz Birinin Mutesini Açarsınız.**
\n ━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
.setImage("")
    .setFooter(`${message.author.tag} Tarafından İstendi.`, message.author.avatarURL())
.addField("**➥ Linkler**", "[:no_entry: Davet Linkim](https://discord.com/api/oauth2/authorize?client_id=812000744806809620&permissions=8&scope=bot)\n\n[:white_check_mark: Destek Sunucum](https://discord.gg/zE4gur3EAw)\n\n[:mega: Websitem](www.lalebot.cf)")
    message.channel.send(embed);

};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: 'moderasyon',
  description: 'Premium Rolü Hakkındaki Bilgileri Gösterir.',
  usage: 'moderasyon'
};