const Discord = require('discord.js');

exports.run = (client, message, args) => {
  
  message.channel.send('**🔥 Yapımcım = <@801068869506433034>**')
  
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: 'yapımcım',
  description: 'nobles api',
  usage: 'yapımcım'
};