const Discord = require('discord.js');
const talkedRecently = new Set();
let botid = ('812000744806809620')

exports.run = (client, message, args) => {
                         if (talkedRecently.has(message.author.id)) {
           return message.reply("");
    } else {

        talkedRecently.add(message.author.id);
        setTimeout(() => {
          // Removes the user from the set after a minute
          talkedRecently.delete(message.author.id);
        }, 2000);// Şuan 2 Saniyedir Değiştirebilirsiniz.
    }
    const embed = new Discord.MessageEmbed()
  .setColor('RED')
.addField('**Yardım Komutları**',`
\n ━━━━━━━━━━━━━━━━━━━━━━━━━━━━
**\n l.koruma : Koruma Komutlarını Gösterir.**
**\n l.eğlence : Eğlence Komutlarını Gösterir.**
**\n l.kullanıcı : Kullanıcı Komutlarını Gösterir.**
**\n l.moderasyon : Moderasyon Komutlarını Gösterir.**
**\n l.ping : Botun Pingini Gösterir.**
**\n l.istatistik : Botun İstatistik lerini Gösterir.**
\n ━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)
.setImage("")
    .setFooter(`${message.author.tag} Tarafından İstendi.`, message.author.avatarURL())
.addField("**➥ Linkler**", "[:no_entry: Davet Linkim](https://discord.com/api/oauth2/authorize?client_id=812000744806809620&permissions=8&scope=bot)\n\n[:white_check_mark: Destek Sunucum](https://discord.gg/zE4gur3EAw)\n\n[:mega: Websitem](www.lalebot.cf)")
    message.channel.send(embed);

};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0,
};

exports.help = {
  name: 'yardım',
  description: 'Premium Rolü Hakkındaki Bilgileri Gösterir.',
  usage: 'yardım'
};